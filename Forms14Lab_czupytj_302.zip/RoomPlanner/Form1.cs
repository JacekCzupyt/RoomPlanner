﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RoomPlanner
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            CenterToScreen();
            newBlueprintToolStripMenuItem_Click(this, null);
        }

        private void newBlueprintToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pictureBox1.Size = pictureBox1.Parent.Size;
            pictureBox1.Image = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            pictureBox1.BackColor = Color.White;
        }


        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.F2)
            {
                newBlueprintToolStripMenuItem_Click(this, null);
            }
        }


        //private void ChangeButtonLocation(object button, int desiredX, int desiredY)
        //{
        //    if()
        //}
    }   
}
